import serial
import time
arduinoWrite = serial.Serial("/dev/ttyACM0",9600)
arduinoRead = serial.Serial("/dev/ttyACM0" ,timeout=1)

def led_on():
    arduinoWrite.write(b'1')

def led_off():
    arduinoWrite.write(b'0')
time.sleep(1)
#t = 0 
#while (t < 2000)
    #if(t % 10 == 0):
       # print(t)

data_raw=[]
while True:
    #data_raw = arduinoData.readline()
    data_raw = arduinoRead.readline()
    data_raw = data_raw.decode('ASCII') 
    #print(arduinoRead.readline())
    print(data_raw)
    time.sleep(2)
    data_raw = float(data_raw)
    if (data_raw < 30.00):
        led_on()
        print("LED ON")
        time.sleep(5)    
    led_off()
    print("LED OFF")
    #time.sleep(1)

    #if ()
    #led_on()
    #print("LED ON")
    #time.sleep(2)
    



