import serial
import time
arduinoWrite = serial.Serial("/dev/ttyACM0",9600)
arduinoRead = serial.Serial("/dev/ttyACM0" ,timeout=1)

def led_on():
    arduinoWrite.write(b'1')

def led_off():
    arduinoWrite.write(b'0')


time.sleep(2)


data_raw=[]

print("Intializing")
print("....")
led_off()



while True:
    if (arduinoRead.readline() != ""):
        data_raw = arduinoRead.readline()
        data_raw = data_raw.decode('ASCII')
        print(data_raw)

        #data_raw = float(data_raw)
        if (data_raw < 30):
         led_on()
         print("LED ON")
        #time.sleep(3) 
        #print("LED OFF")   
        #led_off()
        #time.sleep(3)
        #else if (data_raw )

    



